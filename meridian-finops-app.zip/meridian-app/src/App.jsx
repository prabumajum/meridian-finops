import React, { useState, useEffect, useRef } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";
import {
  Cloud, Server, Cpu, Database, Boxes, Zap, ShieldCheck, Network as NetworkIcon,
  Laptop, HardDrive, Building2, Bot, TrendingDown, AlertTriangle, CheckCircle2,
  Activity, Layers, Terminal, ChevronRight, Radar, Gauge
} from "lucide-react";

// ---------------------------------------------------------------------------
// Design tokens
// ---------------------------------------------------------------------------
const C = {
  bg: "#080D16",
  panel: "#0F1826",
  panelAlt: "#121D2E",
  border: "#1D2B42",
  borderSoft: "#16223580",
  text: "#E7EEF8",
  textMute: "#7E8FAA",
  textFaint: "#4C5C77",
  teal: "#2DD9C2",
  tealSoft: "#1B4A44",
  amber: "#F0A93C",
  amberSoft: "#4A3A18",
  red: "#F0685C",
  redSoft: "#4A2320",
  green: "#4ADE9C",
};

const sevColor = (pct) => (pct >= 25 ? C.red : pct >= 15 ? C.amber : C.teal);
const sevSoft = (pct) => (pct >= 25 ? C.redSoft : pct >= 15 ? C.amberSoft : C.tealSoft);
const fmtM = (n) => `$${n.toFixed(1)}M`;

// ---------------------------------------------------------------------------
// Mock estate data
// ---------------------------------------------------------------------------
const DOMAINS = [
  { id: "cloud", name: "Public Cloud", sub: "AWS · Azure · GCP · OCI", icon: Cloud, cat: "cloud",
    spend: 18.4, leak: 16, finding: "212 idle/oversized instances, 640 unattached volumes across 4 CSPs" },
  { id: "k8s", name: "Kubernetes & Containers", sub: "EKS · AKS · GKE · OpenShift", icon: Boxes, cat: "cloud",
    spend: 6.2, leak: 22, finding: "Requests set 3.1x above actual usage on 58% of workloads" },
  { id: "serverless", name: "Serverless", sub: "Lambda · Functions · Cloud Run", icon: Zap, cat: "cloud",
    spend: 1.8, leak: 9, finding: "Over-provisioned concurrency reservations, cold-start padding" },
  { id: "onprem", name: "On-Prem Servers / DC", sub: "VMware · Bare metal", icon: Server, cat: "cloud",
    spend: 3.9, leak: 12, finding: "Avg 19% CPU utilization on 340 production VMs" },
  { id: "storage", name: "Storage", sub: "SAN · NAS · Object", icon: HardDrive, cat: "cloud",
    spend: 2.6, leak: 19, finding: "Stale snapshots + cold data parked on hot-tier storage" },
  { id: "dr", name: "DR / BCP Sites", sub: "Standby & replication", icon: Building2, cat: "cloud",
    spend: 1.3, leak: 18, finding: "Standby capacity sized for untested peak, never right-sized" },
  { id: "llm", name: "LLM & Token Spend", sub: "OpenAI · Anthropic · Azure OpenAI", icon: Bot, cat: "ai",
    spend: 3.4, leak: 28, finding: "38% of calls use a frontier model for classification-tier tasks" },
  { id: "gpu", name: "Idle GPU / AI Infra", sub: "Training & inference clusters", icon: Cpu, cat: "ai",
    spend: 5.6, leak: 31, finding: "Training clusters idle 41% of allocated hours, no bin-packing" },
  { id: "mainframe", name: "Mainframe & AS/400", sub: "IBM Z · IBM i", icon: Database, cat: "legacy",
    spend: 4.1, leak: 8, finding: "MIPS/MSU capacity licensed above rolling 4-hour average by 14%" },
  { id: "licenses", name: "Software Licenses & SaaS", sub: "Enterprise apps & tools", icon: Layers, cat: "licensing",
    spend: 4.8, leak: 24, finding: "1,140 unused seats, 6 overlapping tools across 3 business units" },
  { id: "network", name: "Network", sub: "MPLS · SD-WAN · Circuits", icon: NetworkIcon, cat: "netsec",
    spend: 1.4, leak: 11, finding: "Redundant circuits at 3 sites post-SD-WAN migration" },
  { id: "security", name: "Security Tooling", sub: "EDR · SIEM · IAM", icon: ShieldCheck, cat: "netsec",
    spend: 2.2, leak: 10, finding: "Overlapping EDR + legacy AV coverage on 2,300 endpoints" },
  { id: "workspace", name: "Workspace & Endpoints", sub: "M365 · Devices", icon: Laptop, cat: "netsec",
    spend: 1.9, leak: 15, finding: "Premium/Copilot seats assigned to 30-day-inactive accounts" },
];

const CATS = [
  { id: "all", label: "All Estates" },
  { id: "cloud", label: "Cloud & Infra" },
  { id: "ai", label: "AI & LLM" },
  { id: "legacy", label: "Legacy Systems" },
  { id: "licensing", label: "Licensing & SaaS" },
  { id: "netsec", label: "Network, Security & Workspace" },
];

const totalSpend = DOMAINS.reduce((s, d) => s + d.spend, 0);
const totalLeak = DOMAINS.reduce((s, d) => s + d.spend * (d.leak / 100), 0);
const leakPct = (totalLeak / totalSpend) * 100;
const actioned = totalLeak * 0.34;

const OPPS = [
  { title: "Right-size idle GPU training clusters", estate: "Idle GPU / AI Infra", impact: 1.74, effort: "Medium", conf: 94 },
  { title: "Route classification tasks to smaller LLM tier", estate: "LLM & Token Spend", impact: 0.71, effort: "Low", conf: 91 },
  { title: "Reclaim unused SaaS seats & consolidate overlap", estate: "Software Licenses", impact: 1.15, effort: "Low", conf: 97 },
  { title: "Right-size Kubernetes requests/limits", estate: "Kubernetes & Containers", impact: 1.02, effort: "Medium", conf: 88 },
  { title: "Decommission orphaned cloud volumes & IPs", estate: "Public Cloud", impact: 0.86, effort: "Low", conf: 96 },
  { title: "Rebalance mainframe MSU capacity to 4hr rolling avg", estate: "Mainframe & AS/400", impact: 0.33, effort: "High", conf: 82 },
];

const PIE = [
  { name: "Cloud & Infra", value: DOMAINS.filter(d=>d.cat==="cloud").reduce((s,d)=>s+d.spend*(d.leak/100),0), color: C.teal },
  { name: "AI & LLM", value: DOMAINS.filter(d=>d.cat==="ai").reduce((s,d)=>s+d.spend*(d.leak/100),0), color: C.red },
  { name: "Legacy Systems", value: DOMAINS.filter(d=>d.cat==="legacy").reduce((s,d)=>s+d.spend*(d.leak/100),0), color: C.textFaint },
  { name: "Licensing & SaaS", value: DOMAINS.filter(d=>d.cat==="licensing").reduce((s,d)=>s+d.spend*(d.leak/100),0), color: C.amber },
  { name: "Net/Sec/Workspace", value: DOMAINS.filter(d=>d.cat==="netsec").reduce((s,d)=>s+d.spend*(d.leak/100),0), color: "#6E8FE0" },
];

const CONNECTORS = [
  "AWS", "Azure", "GCP", "OCI", "VMware vSphere", "IBM Z Mainframe", "IBM i / AS-400",
  "Kubernetes", "OpenShift", "AWS Lambda", "Azure Functions", "ServiceNow CMDB", "Okta / AD", "SNMP / NetFlow"
];

const LOG_TEMPLATES = [
  { agent: "GPU-Sentinel", msg: "flagged 6 A100 nodes idle >18h in ap-south-1 training pool" },
  { agent: "TokenAudit", msg: "detected repeated uncached system prompts inflating input tokens 3.2x" },
  { agent: "LicenseReco", msg: "cross-referenced SSO logs — 340 Figma seats unused 45+ days" },
  { agent: "MainframeWatch", msg: "IBM i CPW allocation 14% above rolling peak, proposing tier step-down" },
  { agent: "K8s-Trimmer", msg: "generated VPA recommendation for checkout-service, est. 38% CPU reduction" },
  { agent: "CloudReaper", msg: "found 640 unattached EBS/managed disks across 4 regions, safe to snapshot+purge" },
  { agent: "NetOptimizer", msg: "site DXB-DR2 running duplicate MPLS + SD-WAN, one link unused since migration" },
  { agent: "SecOverlap", msg: "EDR and legacy AV both active on 2,300 endpoints — consolidation candidate" },
  { agent: "StorageTiering", msg: "1.8TB of snapshots >180 days old sitting on hot-tier NAS" },
  { agent: "DR-Sizing", msg: "DR standby sized for 3x untested peak load, recommends right-sizing to 1.4x" },
  { agent: "WorkspaceAudit", msg: "112 Copilot licenses assigned to accounts inactive 30+ days" },
  { agent: "ServerlessWatch", msg: "Lambda concurrency reserved 4x above p99 observed traffic" },
];

// ---------------------------------------------------------------------------
// Small building blocks
// ---------------------------------------------------------------------------
function KPI({ label, value, sub, icon: Icon, tone }) {
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-xl p-4 flex-1 min-w-[150px]">
      <div className="flex items-center justify-between mb-3">
        <span style={{ color: C.textMute }} className="text-[11px] tracking-wide uppercase font-mono">{label}</span>
        <Icon size={15} style={{ color: tone || C.teal }} />
      </div>
      <div style={{ color: C.text }} className="text-2xl font-semibold font-mono tabular-nums">{value}</div>
      {sub && <div style={{ color: C.textFaint }} className="text-[11px] mt-1 font-mono">{sub}</div>}
    </div>
  );
}

function DomainCard({ d }) {
  const Icon = d.icon;
  const color = sevColor(d.leak);
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.border}` }}
      className="rounded-xl p-4 flex flex-col gap-3 hover:border-[#2DD9C2]/40 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5">
          <div style={{ background: C.panelAlt, border: `1px solid ${C.border}` }} className="rounded-lg p-2">
            <Icon size={16} style={{ color: C.teal }} />
          </div>
          <div>
            <div style={{ color: C.text }} className="text-[13px] font-medium leading-tight">{d.name}</div>
            <div style={{ color: C.textFaint }} className="text-[10.5px] font-mono">{d.sub}</div>
          </div>
        </div>
        <span style={{ color, background: sevSoft(d.leak) }} className="text-[10.5px] font-mono px-1.5 py-0.5 rounded shrink-0">
          {d.leak}%
        </span>
      </div>

      <div className="flex items-baseline justify-between font-mono">
        <span style={{ color: C.text }} className="text-lg tabular-nums">{fmtM(d.spend)}</span>
        <span style={{ color }} className="text-[11px] tabular-nums">leak {fmtM(d.spend * d.leak / 100)}</span>
      </div>

      <div style={{ background: C.borderSoft }} className="h-1.5 rounded-full overflow-hidden">
        <div style={{ width: `${d.leak}%`, background: color }} className="h-full rounded-full" />
      </div>

      <p style={{ color: C.textMute }} className="text-[11.5px] leading-snug">{d.finding}</p>
    </div>
  );
}

function AgentLog() {
  const [lines, setLines] = useState([]);
  const boxRef = useRef(null);
  const idxRef = useRef(0);

  useEffect(() => {
    const iv = setInterval(() => {
      const t = LOG_TEMPLATES[idxRef.current % LOG_TEMPLATES.length];
      idxRef.current += 1;
      const now = new Date();
      const ts = now.toLocaleTimeString("en-GB", { hour12: false });
      setLines((prev) => [...prev.slice(-24), { ts, ...t }]);
    }, 1800);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    if (boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight;
  }, [lines]);

  return (
    <div style={{ background: "#060A11", border: `1px solid ${C.border}` }} className="rounded-xl overflow-hidden flex flex-col h-full">
      <div style={{ borderBottom: `1px solid ${C.border}`, background: C.panelAlt }} className="px-4 py-2.5 flex items-center gap-2">
        <Terminal size={13} style={{ color: C.teal }} />
        <span style={{ color: C.text }} className="text-[11.5px] font-mono">agent_activity.log</span>
        <span className="ml-auto flex items-center gap-1.5">
          <span style={{ background: C.green }} className="w-1.5 h-1.5 rounded-full animate-pulse" />
          <span style={{ color: C.textFaint }} className="text-[10px] font-mono">13 agents live</span>
        </span>
      </div>
      <div ref={boxRef} className="px-4 py-3 overflow-y-auto flex-1 font-mono text-[11.5px] leading-relaxed" style={{ maxHeight: 300 }}>
        {lines.length === 0 && <div style={{ color: C.textFaint }}>booting agents…</div>}
        {lines.map((l, i) => (
          <div key={i} className="mb-1.5">
            <span style={{ color: C.textFaint }}>{l.ts}</span>{" "}
            <span style={{ color: C.teal }}>{l.agent}</span>{" "}
            <span style={{ color: C.textMute }}>›</span>{" "}
            <span style={{ color: C.text }}>{l.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
export default function App() {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? DOMAINS : DOMAINS.filter((d) => d.cat === cat);
  const chartData = DOMAINS.map((d) => ({
    name: d.name.split(" ")[0] + (d.name.split(" ")[1] && d.name.split(" ")[1].length < 5 ? " " + d.name.split(" ")[1] : ""),
    spend: +d.spend.toFixed(1),
    leak: +(d.spend * d.leak / 100).toFixed(2),
  }));

  return (
    <div style={{ background: C.bg, color: C.text, minHeight: "100vh", fontFamily: "'IBM Plex Sans', system-ui, sans-serif" }} className="w-full">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" />

      {/* Top bar */}
      <div style={{ borderBottom: `1px solid ${C.border}`, background: "linear-gradient(180deg, #0B121E 0%, #080D16 100%)" }} className="px-6 py-4">
        <div className="max-w-[1400px] mx-auto flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div style={{ background: C.tealSoft, border: `1px solid ${C.teal}55` }} className="rounded-lg p-2">
              <Radar size={20} style={{ color: C.teal }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 style={{ letterSpacing: "0.01em" }} className="text-[18px] font-semibold">Meridian</h1>
                <span style={{ color: C.textFaint, border: `1px solid ${C.border}` }} className="text-[9.5px] font-mono px-1.5 py-0.5 rounded uppercase">Demo Environment</span>
              </div>
              <p style={{ color: C.textMute }} className="text-[11.5px] font-mono">Agentic FinOps control plane — mainframe to multi-cloud to LLM tokens</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span style={{ background: C.tealSoft, color: C.teal, border: `1px solid ${C.teal}40` }} className="flex items-center gap-1.5 text-[11px] font-mono px-2.5 py-1.5 rounded-full">
              <Activity size={12} /> 13 agents scanning
            </span>
            <span style={{ color: C.textFaint }} className="text-[11px] font-mono hidden sm:block">last sync: just now</span>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-6 py-6 flex flex-col gap-6">

        {/* KPIs */}
        <div className="flex flex-wrap gap-3">
          <KPI label="Total Managed Spend" value={fmtM(totalSpend)} sub="Annualized, across 13 estates" icon={Gauge} tone={C.teal} />
          <KPI label="Leakage Identified" value={fmtM(totalLeak)} sub={`${leakPct.toFixed(1)}% of total spend`} icon={AlertTriangle} tone={C.amber} />
          <KPI label="Savings Actioned" value={fmtM(actioned)} sub="Auto-remediated or approved YTD" icon={CheckCircle2} tone={C.green} />
          <KPI label="Active Agents" value="13" sub="Domain-specialized, always-on" icon={Bot} tone={C.teal} />
        </div>

        {/* Connector strip */}
        <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-xl px-4 py-3 flex flex-wrap items-center gap-x-5 gap-y-2">
          <span style={{ color: C.textFaint }} className="text-[10.5px] font-mono uppercase tracking-wide">Hardware &amp; cloud-agnostic connectors</span>
          {CONNECTORS.map((c) => (
            <span key={c} style={{ color: C.textMute }} className="text-[11.5px] font-mono flex items-center gap-1">
              <ChevronRight size={11} style={{ color: C.teal }} /> {c}
            </span>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-4">
          <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 style={{ color: C.text }} className="text-[13px] font-medium">Spend vs. leakage by estate</h2>
              <div className="flex items-center gap-3 text-[10.5px] font-mono" style={{ color: C.textFaint }}>
                <span className="flex items-center gap-1"><span style={{ background: C.teal }} className="w-2 h-2 rounded-sm" /> spend</span>
                <span className="flex items-center gap-1"><span style={{ background: C.red }} className="w-2 h-2 rounded-sm" /> leakage</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData} margin={{ top: 4, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid stroke={C.border} vertical={false} />
                <XAxis dataKey="name" tick={{ fill: C.textFaint, fontSize: 10, fontFamily: "IBM Plex Mono" }} interval={0} angle={-30} textAnchor="end" height={60} />
                <YAxis tick={{ fill: C.textFaint, fontSize: 10, fontFamily: "IBM Plex Mono" }} tickFormatter={(v) => `$${v}M`} />
                <Tooltip contentStyle={{ background: C.panelAlt, border: `1px solid ${C.border}`, borderRadius: 8, fontFamily: "IBM Plex Mono", fontSize: 11 }}
                  formatter={(v) => [`$${v}M`, ""]} labelStyle={{ color: C.text }} />
                <Bar dataKey="spend" fill={C.teal} radius={[3, 3, 0, 0]} opacity={0.35} />
                <Bar dataKey="leak" fill={C.red} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-xl p-4">
            <h2 style={{ color: C.text }} className="text-[13px] font-medium mb-3">Leakage distribution</h2>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={PIE} dataKey="value" nameKey="name" innerRadius={48} outerRadius={78} paddingAngle={2}>
                  {PIE.map((p, i) => <Cell key={i} fill={p.color} stroke={C.panel} strokeWidth={2} />)}
                </Pie>
                <Tooltip contentStyle={{ background: C.panelAlt, border: `1px solid ${C.border}`, borderRadius: 8, fontFamily: "IBM Plex Mono", fontSize: 11 }}
                  formatter={(v) => [`$${v.toFixed(2)}M`, ""]} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-col gap-1.5 mt-1">
              {PIE.map((p) => (
                <div key={p.name} className="flex items-center justify-between text-[11px] font-mono">
                  <span className="flex items-center gap-1.5" style={{ color: C.textMute }}>
                    <span style={{ background: p.color }} className="w-2 h-2 rounded-full" /> {p.name}
                  </span>
                  <span style={{ color: C.text }}>{fmtM(p.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Category filter */}
        <div className="flex flex-wrap gap-2">
          {CATS.map((c) => (
            <button key={c.id} onClick={() => setCat(c.id)}
              style={{
                background: cat === c.id ? C.tealSoft : C.panel,
                color: cat === c.id ? C.teal : C.textMute,
                border: `1px solid ${cat === c.id ? C.teal + "55" : C.border}`,
              }}
              className="text-[11.5px] font-mono px-3 py-1.5 rounded-full transition-colors">
              {c.label}
            </button>
          ))}
        </div>

        {/* Domain grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((d) => <DomainCard key={d.id} d={d} />)}
        </div>

        {/* Opportunities + Agent log */}
        <div className="grid grid-cols-1 lg:grid-cols-[1.3fr_1fr] gap-4">
          <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-xl overflow-hidden">
            <div style={{ borderBottom: `1px solid ${C.border}` }} className="px-4 py-3 flex items-center gap-2">
              <TrendingDown size={14} style={{ color: C.teal }} />
              <h2 style={{ color: C.text }} className="text-[13px] font-medium">Top savings opportunities</h2>
            </div>
            <div>
              {OPPS.sort((a, b) => b.impact - a.impact).map((o, i) => (
                <div key={i} style={{ borderBottom: i < OPPS.length - 1 ? `1px solid ${C.borderSoft}` : "none" }}
                  className="px-4 py-3 flex items-center gap-3">
                  <span style={{ color: C.textFaint }} className="text-[11px] font-mono w-4">{String(i + 1).padStart(2, "0")}</span>
                  <div className="flex-1 min-w-0">
                    <div style={{ color: C.text }} className="text-[12.5px] font-medium truncate">{o.title}</div>
                    <div style={{ color: C.textFaint }} className="text-[10.5px] font-mono">{o.estate} · effort: {o.effort} · confidence {o.conf}%</div>
                  </div>
                  <span style={{ color: C.green }} className="text-[13px] font-mono tabular-nums shrink-0">+{fmtM(o.impact)}</span>
                </div>
              ))}
            </div>
          </div>

          <AgentLog />
        </div>

        <div style={{ color: C.textFaint, borderTop: `1px solid ${C.border}` }} className="text-[10.5px] font-mono text-center pt-4 pb-2">
          Meridian is a demo build on illustrative data — spend, leakage, and agent findings are simulated for walkthrough purposes.
        </div>
      </div>
    </div>
  );
}
